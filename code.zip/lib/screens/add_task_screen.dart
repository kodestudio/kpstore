import 'package:flutter/material.dart';

import '../database/tasks_db.dart';
import '../models/task.dart';

class AddTaskScreen extends StatefulWidget {
  static const id = 'add_task_screen';

  final Task task;

  AddTaskScreen(this.task);

  @override
  _AddTaskScreenState createState() => _AddTaskScreenState();
}

class _AddTaskScreenState extends State<AddTaskScreen> {
  final _taskController = TextEditingController();
  bool _inSync = false;
  String _taskError;

  @override
  void initState() {
    Task task = widget.task;
    if (task != null) {
      _taskController.text = task.task;
    }
    super.initState();
  }

  void addTask() async {
    if (_taskController.text.isEmpty) {
      setState(() {
        _taskError = 'Please enter this field';
      });
      return null;
    }
    setState(() {
      _taskError = null;
      _inSync = true;
    });
    final db = TasksDB();
    final task = Task(
      task: _taskController.text.trim(),
    );
    await db.insert(task);
    setState(() {
      _inSync = false;
    });
    Navigator.pop(context, true);
  }

  void updateTask() async {
    if (_taskController.text.isEmpty) {
      setState(() {
        _taskError = 'Please enter this field';
      });
      return null;
    }
    setState(() {
      _taskError = null;
      _inSync = true;
    });
    final db = TasksDB();
    final task = Task(
      id: widget.task.id,
      task: _taskController.text.trim(),
    );
    await db.update(task);
    setState(() {
      _inSync = false;
    });
    Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Add task'),
        backgroundColor: Colors.white,
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: !_inSync
              ? () {
                  Navigator.pop(context);
                }
              : null,
        ),
        actions: <Widget>[
          !_inSync
              ? IconButton(
                  icon: Icon(Icons.done),
                  onPressed: () {
                    widget.task == null ? addTask() : updateTask();
                  },
                )
              : Icon(Icons.refresh),
        ],
        elevation: 0.0,
        textTheme: TextTheme(
          title: Theme.of(context).textTheme.title,
        ),
        iconTheme: IconThemeData(
          color: Colors.black87,
        ),
      ),
      body: WillPopScope(
        onWillPop: () async {
          if (!_inSync) return true;
          return false;
        },
        child: Padding(
          padding: EdgeInsets.all(16.0),
          child: TextField(
            controller: _taskController,
            decoration: InputDecoration(
              labelText: 'Task',
              errorText: _taskError,
              border: OutlineInputBorder(),
            ),
          ),
        ),
      ),
    );
  }
}
