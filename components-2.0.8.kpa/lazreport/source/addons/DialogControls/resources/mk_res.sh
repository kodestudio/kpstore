#!/bin/sh
../../../../../../tools/lazres ../lrdbdialogcontrols_img.res tlrdblookupcombobox.bmp
../../../../../../tools/lazres ../lrdialogcontrols_img.res @lrdialogcontrols_img.txt
