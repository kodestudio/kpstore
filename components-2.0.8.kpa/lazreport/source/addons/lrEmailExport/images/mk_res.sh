#!/bin/sh
../../../../../../tools/lazres ../lremailexport.res @img.txt
