How to update icons:

../../../tools/lazres cody.res tcodytreeview.png

