#!/bin/bash
../../../../../tools/lazres ../lazhelpchm.lrs @lazhelpchm.txt
