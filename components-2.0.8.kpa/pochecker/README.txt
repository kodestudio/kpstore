This package checks the validity of translated PO files.

Original version made by Bart Broersma

ToDo:
 - Automatically find all PO files belonging to the current project.
 - Improve IDE integration
