A standalone application to check the validity of translated PO files.
Uses the same source files as the PoChecker package.
