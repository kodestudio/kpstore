../../../tools/lazres ../registersqldb.res @registersqldb.txt
