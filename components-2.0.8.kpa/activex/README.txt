LazActiveX Package
------------------
The LazActiveX package contains the TActiveXContainer component and the IDE
integration of the necessary tools to create ActiveX components from a type
library or directly from the object (exe or dll).

REQUIREMENTS:
-------------
Windows XP or newer
FPC >= 2.6.1

DOCUMENTATION:
--------------
Documentation and samples can be found at http://wiki.freepascal.org/LazActiveX


