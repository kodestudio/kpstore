# RemObjects Pascal Script
Created By Carlo Kok 	   			
ck@remobjects.com

Copyright (C) 2000-2014 by Carlo Kok and RemObjects Software, LLC

This software is provided 'as-is', without any expressed or implied warranty. In no event will the author be held liable for any damages arising from the use of this software.
Permission is granted to anyone to use this software for any kind of application, and to alter it and redistribute it freely, subject to the following restrictions:

1. The origin of this software must not be misrepresented, you must not claim that you wrote the original software.
2. Altered source versions must be plainly marked as such, and must not be misrepresented as being the original software.
3. You must have a visible line in your programs aboutbox or documentation that it is made using RemObjects Pascal Script and where RemObjects Pascal Script can be found.
4. This notice may not be removed or altered from any source distribution.

If you have any questions concerning this license contact info@remobjects.com

Carlo Kok, RemObjects Software

