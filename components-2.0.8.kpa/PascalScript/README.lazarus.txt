﻿This folder contains a partial copy of 

RemObjects Pascal Script 
Created by Carlo Kok
RemObjects Software
Fixed for Lazarus by Bogusіaw Brandys

For details also see the description in the lpk file (Lazarus Package).
For license details see LICENSE.md or the package file.


This copy only provides the files required by the Lazarus IDE (edior macros).

The original distribution also contains files for using PascalScript in Delphi and
additional documentation.

Files in this distributions may also be modified or outdated.

In case of any issues you are advised to check the original distribution at https://github.com/remobjects/pascalscript/
