This directory contains the IDE interfaces for experts/plugins.

These files are under the modified LGPL as described in COPYING.modifiedLGPL.

