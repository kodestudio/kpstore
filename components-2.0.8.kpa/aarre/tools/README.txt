aarreupdatelist is a command line utility to scan a directory for lpk files
and write a summary. Compile and run to see the available parameters.


