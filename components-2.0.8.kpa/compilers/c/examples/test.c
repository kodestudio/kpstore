#include <stdio.h>

public void main()
{
  printf("Hello World \n");
