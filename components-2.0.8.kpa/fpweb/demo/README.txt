The examples were moved to the FPC sources.
See <fpcsrc>/packages/fcl-web/examples
